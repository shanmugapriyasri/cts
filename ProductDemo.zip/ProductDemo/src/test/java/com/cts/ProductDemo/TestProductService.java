package com.cts.ProductDemo;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;


import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import org.springframework.transaction.annotation.Transactional;

import com.cts.model.Product;
import com.cts.repository.ProductRepository;
import com.cts.service.ProductService;
import com.cts.service.ProductServiceImpl;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class TestProductService {


	
    ProductService productService;
	
	@Autowired
	ProductRepository repository;
	
  
	
	  @BeforeEach
	  public void setup() {
		  productService=new ProductServiceImpl(repository);
	  }
   	  
	  @Test
	  public void m1() {
		
		 assertNotNull(productService);
		 assertNotNull(repository);
	  }
   
    @Test
    @Transactional
    public void getAllProductsTest()
    {	
        List<Product> pList = productService.getAllProducts();
        System.out.println(pList);
         
        assertTrue(pList.size()>0);
      
    }

    @Test
    @Transactional
    public void testSave()
    {	 Product pOne=new Product("LGTelevision", "45 inch television", 95656.0, "television");
    
    productService.save(pOne);
    System.out.println(pOne.getPid());
    assertNotNull(pOne.getPid());
    assertTrue(pOne.getPid()>0);
      
    }

    
    @Test
    @Transactional
    public void testFindById_postive()
    {	 Product p=productService.getProductById(6);
       assertNotNull(p);
      
    }

    @Test
    @Transactional
    public void testFindById_negative()
    {	try {
        Product p=productService.getProductById(666);
        
       assertNull(p);
   	}catch(Exception e) {
   		//assertEquals(expected, actual);
   	}
      
    }

    
}
