package com.cts.ProductDemo;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.junit.jupiter.SpringExtension;

import org.springframework.transaction.annotation.Transactional;


import com.cts.model.Product;
import com.cts.repository.ProductRepository;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class TestProductRepository {

	
	@Autowired
    ProductRepository repository;
     
	
	
	 
	 
		
	  @Test
	  public void m1() {
		 assertNotNull(repository);
	  }
   // @Test
    public void testSave() 
    {
    	 Product pOne=new Product("SonyTelevision", "45 inch television", 78000.0, "television");
         
        repository.save(pOne);
         System.out.println(pOne.getPid());
     assertNotNull(pOne.getPid());
    }

    
    @Test
    public void testFindById_postive() 
    {
 	
        Product p=repository.getOne(6);
         System.out.println("kkkkkkkk"+p);
        assertNotNull(p);
    }
    @Test
   public void testFindById_negative() 
    {   
    	try {
        Product p=repository.getOne(62);
         System.out.println("kkkkkkkk"+p);
        assertNull(p);
    	}catch(Exception e) {
    		//assertEquals(expected, actual);
    	}
    }
    
    @Test
    public void testFindAll_positive() 
     {   
     	try {
         List<Product> plist=repository.findAll();
          
         assertTrue(plist.size()>0);
     	}catch(Exception e) {
     		
     	}
     }
}
