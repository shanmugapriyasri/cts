package com.cts.ProductDemo;


import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BindingResult;
import org.springframework.web.context.WebApplicationContext;

import com.cts.controller.ProductController;
import com.cts.model.Product;
import com.cts.service.ProductService;

@SpringBootTest
//@TestInstance(Lifecycle.PER_CLASS)
class ProductDemoApplicationTests {

	
	 	private MockMvc mockMvc;
	    @Autowired
	    private WebApplicationContext webApplicationContext;
	    @MockBean
	    private ProductService productServiceMock;
	    
	    @InjectMocks
		private ProductController controller;


		
		@Mock
		private BindingResult bindingResult;
	    
	    @BeforeEach
	    public void setUp() {
	        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	        MockitoAnnotations.initMocks(this);
			
	        this.mockMvc = MockMvcBuilders.standaloneSetup(this.controller).build();
	        System.out.println(this.mockMvc);
	   	 Mockito.when(bindingResult.hasErrors()).thenReturn(false);
	    }
	  @Test
	    public void testList() throws Exception {
	       // assertThat(this.productServiceMock).isNotNull();
	    	//Product product=new Product();
	    	Mockito.when(bindingResult.hasErrors()).thenReturn(true);

			 RequestBuilder request = MockMvcRequestBuilders.post("/save")
					 .param("pid", "999")
				    .param("pname", "Rkjh777")
				    .param("decription","kjkjkjdesc").
				    param("price", "12892.21").
				    param("category", "toy");
	        mockMvc.perform(request)
	                .andExpect(status().isOk())
	                .andExpect(view().name("viewproduct"))
	                .andExpect(MockMvcResultMatchers.view().name("viewproduct"));
	            
	}
	@Test
	void contextLoads() {
	}

	
	
}
