package com.cts.ProductDemo;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.queryParam;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.controller.ProductController;
import com.cts.model.Product;
import com.cts.service.ProductService;
import com.cts.service.ProductServiceImpl;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TestCotrollerProduct {

	@InjectMocks
	 ProductController controller;
	
	@Autowired
	MockHttpSession session;

	@Autowired
	private MockMvc mvc;
	
	 @Autowired
	 ProductService productService;

	
	 // @MockBean 
	  //ProductServiceImpl productService;
	  
	 
	 @BeforeEach public void setup() { 
	//this.controller=new ProductController(productService);	 
		 MockitoAnnotations.initMocks(this);
			
	        this.mvc = MockMvcBuilders.standaloneSetup(this.controller).build();
	        System.out.println("%%%%%%%%%%"+this.mvc);	 
	 }
	 
	@Test
	public void beforeAll() {
		assertNotNull(mvc);
		assertNotNull(productService);
		}

	 @AfterEach
	public void tearDown() throws Exception {
		

	}

	/**
	 * Test case to test the positive scenario for showproductform method
	 */
	// @Test
	public void testshowproductform_Positive() {
		Product product = null;
		try {
			product = new Product();
			RequestBuilder request = MockMvcRequestBuilders.get("/showform").flashAttr("product", product);
			mvc.perform(request)
			.andExpect(status().isOk())
			.andExpect(view().name("productform"));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	/**
	 * Test case to test the negative case, wrong url scenario for showproductform method
	 */
	 //@Test
	public void testshowproductform_WrongUrl() {

		try {
			mvc.perform(get("/showformwrong")).andExpect(status().is(404));

		} catch (Exception exception) {
			fail("Exception");
		}

	}

	//@Test
	public void testviewAllProducts() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewproduct");
			mvc.perform(request).andExpect(status().isOk()).andExpect(view().name("viewproductpage"));
		} catch (Exception e) {
			fail(e);
		}
	}

	//@Test
	public void testviewAllProducts_wrongurl() {
		try {
			RequestBuilder request = MockMvcRequestBuilders.get("/viewallproduct");
			mvc.perform(request).andExpect(status().is(404));
		} catch (Exception e) {
			fail(e);
		}
	}

	
	 //@Test
	    void testsearchbyCategory() throws Exception {
		 
		 RequestBuilder request = MockMvcRequestBuilders.get("/search")
		 .param("category", "mobile");
	     
		 mvc.perform(request)
		 .andExpect(view().name("redirect:/viewproduct"))
		 .andExpect(redirectedUrl("/viewproduct"));
		 //.andExpect(model().size(5));
		 

	        }
	 
		
	// @Test
	    void testsearchByange() throws Exception {
		 
		 RequestBuilder request = MockMvcRequestBuilders.get("/searchbyrange")
		 .param("min", "5000.0")
		 .param("max", "70000.0");
	     
		 mvc.perform(request)
		 .andExpect(view().name("redirect:/viewproduct"))
		 .andExpect(redirectedUrl("/viewproduct"));
		 //.andExpect(model().size(5));
		 

	        }
	 
	 
		
	 @Test
	    void testdeleteByIdWithValidId() throws Exception {
		 HashMap<String, Object> sessionattr = new HashMap<String, Object>();
		 sessionattr.put("clist",new ArrayList<Product>());
		 sessionattr.put("rlist",new ArrayList<Product>());
		
		
		// HttpSession ses=mock(HttpSession.class);
		 RequestBuilder request = MockMvcRequestBuilders.delete("/delete")
		 .param("pid", "15")
		 .session(session).sessionAttrs(sessionattr);
		 
				 mvc.perform(request)
		 .andExpect(view().name("redirect:/viewproduct"))
		 .andExpect(redirectedUrl("/viewproduct"));
		 //.andExpect(model().size(5));
		 

	        }
	 
}
