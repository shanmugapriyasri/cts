package com.cts.service;

import java.util.List;

import com.cts.model.Product;

public interface ProductService {

	void save(Product product);
	List<Product> getAllProducts();
	Product getProductById(int pid);
	void deleteById(int pid);
	List<Product> searchByCategory(String category);
	List<Product> getProductsByRange(double min, double max);
}
