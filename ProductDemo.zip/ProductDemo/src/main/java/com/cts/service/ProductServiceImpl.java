package com.cts.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Product;
import com.cts.repository.ProductRepository;
@Service
@Transactional
public class ProductServiceImpl  implements ProductService{

	@Autowired
	ProductRepository productRepository;

	
public ProductServiceImpl() {

}


	public ProductServiceImpl(ProductRepository productRepository) {
	super();
	this.productRepository = productRepository;
}


	@Override
	public void save(Product product) {
		productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		
		List<Product> plist=productRepository.findAll();
		System.out.println("service"+plist);
		
		return plist;
	}

	@Override
	public Product getProductById(int pid) {
		// TODO Auto-generated method stub
		return productRepository.getOne(pid);
	}

	@Override
	public void deleteById(int pid) {
		// TODO Auto-generated method stub
		productRepository.deleteById(pid);
		
	}

	@Override
	public List<Product> searchByCategory(String category) {
		// TODO Auto-generated method stub
		return productRepository.getProductsByCategory(category);
	}

	@Override
	public List<Product> getProductsByRange(double min, double max) {
		// TODO Auto-generated method stub
		return productRepository.getProductsByRange(min, max);
	}

	
}
