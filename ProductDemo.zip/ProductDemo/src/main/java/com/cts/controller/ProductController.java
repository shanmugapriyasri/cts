package com.cts.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.repository.ProductRepository;
import com.cts.service.ProductService;
import com.cts.service.ProductServiceImpl;
import com.cts.model.Product;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	HttpSession session;
	
	public ProductController() {
		// TODO Auto-generated constructor stub
	}
	
	
	
/*	public ProductController(ProductServiceImpl productService) {
		super();
		this.productService = productService;
		System.out.println("*************"+productService);
	}
*/


	@RequestMapping("/showform")
	public String showproductform(@ModelAttribute("product")  Product product) {
		product=new Product();
		
		return "productform";
	}
	
	@RequestMapping("/save")
	public String addProduct(@Valid @ModelAttribute("product")  Product product,	BindingResult bindingResult) {
		try {
			System.out.println("tesing"+product);
			System.out.println("testing"+bindingResult);
//	System.out.println(bindingResult.hasErrors());
			if(bindingResult.hasErrors()) {
			System.out.println("inside testing");
							
				
				System.out.println("ui details not correct");
				return "productform";
			}else {
				System.out.println("elseeeeeeeeeeeeeeeeeeeeee ************** eeeeeeeeeeeeeeeeeeeeeeeeeeee"+productService);
				productService.save(product);
			System.out.println("after save"+product);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/viewproduct";
	}
	
	@RequestMapping("/viewproduct")
	public String viewallProduct(Model m) {
		
		List<Product> productlist=productService.getAllProducts();
		m.addAttribute("plist",productlist);
		return "viewproductpage";
	}
	
	@RequestMapping("/updateform")
	public String updateform(@RequestParam int pid, @ModelAttribute("product")  Product product,Model model) {
		Product pp=productService.getProductById(pid);
	//	product=pp.get();
		model.addAttribute(pp);
	//	System.out.println(product);
		return "updateform";
	}
	@RequestMapping("/delete")
	public String delete(@RequestParam int pid) {
		productService.deleteById(pid);
		System.out.println(pid+"deleted");
		System.out.println("??????????"+session);
		session.removeAttribute("clist");
		session.removeAttribute("rlist");
		return "redirect:/viewproduct";
	}
	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("product") Product product) {
		productService.save(product);
		session.removeAttribute("clist");
		session.removeAttribute("rlist");
	return "redirect:/viewproduct";
	}
	
	@RequestMapping("/search")
	public String searchbyCategory(@RequestParam String category,HttpServletRequest request) {
		List<Product> catList=productService.searchByCategory(category);
	//System.out.println(catList);
		System.out.println(catList.size());
	 session=request.getSession();
	session.setAttribute("clist", catList);
	session.removeAttribute("rlist");
			return "redirect:/viewproduct";
	}
	@RequestMapping("/searchbyrange")
	public String searchbyRange(@RequestParam double min,@RequestParam double max,HttpServletRequest request) {
		List<Product> rangeList=productService.getProductsByRange(min, max);
	System.out.println("ragnge:"+rangeList);
	 session=request.getSession();
	session.setAttribute("rlist", rangeList);
	session.removeAttribute("clist");
			return "redirect:/viewproduct";
	}
}
